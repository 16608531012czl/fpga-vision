// ==============================================================
// File generated on Fri Sep 18 18:16:15 +0800 2026
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2018.3 (64-bit)
// SW Build 2405991 on Thu Dec  6 23:38:27 MST 2018
// IP Build 2404404 on Fri Dec  7 01:43:56 MST 2018
// Copyright 1986-2018 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#include "xparameters.h"
#include "xcolor_convert.h"

extern XColor_convert_Config XColor_convert_ConfigTable[];

XColor_convert_Config *XColor_convert_LookupConfig(u16 DeviceId) {
	XColor_convert_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XCOLOR_CONVERT_NUM_INSTANCES; Index++) {
		if (XColor_convert_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XColor_convert_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XColor_convert_Initialize(XColor_convert *InstancePtr, u16 DeviceId) {
	XColor_convert_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XColor_convert_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XColor_convert_CfgInitialize(InstancePtr, ConfigPtr);
}

#endif

