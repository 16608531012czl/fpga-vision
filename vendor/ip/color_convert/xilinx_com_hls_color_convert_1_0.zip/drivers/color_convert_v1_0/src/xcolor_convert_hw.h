// ==============================================================
// File generated on Fri Sep 18 18:16:15 +0800 2026
// Vivado(TM) HLS - High-Level Synthesis from C, C++ and SystemC v2018.3 (64-bit)
// SW Build 2405991 on Thu Dec  6 23:38:27 MST 2018
// IP Build 2404404 on Fri Dec  7 01:43:56 MST 2018
// Copyright 1986-2018 Xilinx, Inc. All Rights Reserved.
// ==============================================================
// AXILiteS
// 0x00 : reserved
// 0x04 : reserved
// 0x08 : reserved
// 0x0c : reserved
// 0x10 : Data signal of c1_c1_V
//        bit 9~0 - c1_c1_V[9:0] (Read/Write)
//        others  - reserved
// 0x14 : reserved
// 0x18 : Data signal of c1_c2_V
//        bit 9~0 - c1_c2_V[9:0] (Read/Write)
//        others  - reserved
// 0x1c : reserved
// 0x20 : Data signal of c1_c3_V
//        bit 9~0 - c1_c3_V[9:0] (Read/Write)
//        others  - reserved
// 0x24 : reserved
// 0x28 : Data signal of c2_c1_V
//        bit 9~0 - c2_c1_V[9:0] (Read/Write)
//        others  - reserved
// 0x2c : reserved
// 0x30 : Data signal of c2_c2_V
//        bit 9~0 - c2_c2_V[9:0] (Read/Write)
//        others  - reserved
// 0x34 : reserved
// 0x38 : Data signal of c2_c3_V
//        bit 9~0 - c2_c3_V[9:0] (Read/Write)
//        others  - reserved
// 0x3c : reserved
// 0x40 : Data signal of c3_c1_V
//        bit 9~0 - c3_c1_V[9:0] (Read/Write)
//        others  - reserved
// 0x44 : reserved
// 0x48 : Data signal of c3_c2_V
//        bit 9~0 - c3_c2_V[9:0] (Read/Write)
//        others  - reserved
// 0x4c : reserved
// 0x50 : Data signal of c3_c3_V
//        bit 9~0 - c3_c3_V[9:0] (Read/Write)
//        others  - reserved
// 0x54 : reserved
// 0x58 : Data signal of bias_c1_V
//        bit 9~0 - bias_c1_V[9:0] (Read/Write)
//        others  - reserved
// 0x5c : reserved
// 0x60 : Data signal of bias_c2_V
//        bit 9~0 - bias_c2_V[9:0] (Read/Write)
//        others  - reserved
// 0x64 : reserved
// 0x68 : Data signal of bias_c3_V
//        bit 9~0 - bias_c3_V[9:0] (Read/Write)
//        others  - reserved
// 0x6c : reserved
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

#define XCOLOR_CONVERT_AXILITES_ADDR_C1_C1_V_DATA   0x10
#define XCOLOR_CONVERT_AXILITES_BITS_C1_C1_V_DATA   10
#define XCOLOR_CONVERT_AXILITES_ADDR_C1_C2_V_DATA   0x18
#define XCOLOR_CONVERT_AXILITES_BITS_C1_C2_V_DATA   10
#define XCOLOR_CONVERT_AXILITES_ADDR_C1_C3_V_DATA   0x20
#define XCOLOR_CONVERT_AXILITES_BITS_C1_C3_V_DATA   10
#define XCOLOR_CONVERT_AXILITES_ADDR_C2_C1_V_DATA   0x28
#define XCOLOR_CONVERT_AXILITES_BITS_C2_C1_V_DATA   10
#define XCOLOR_CONVERT_AXILITES_ADDR_C2_C2_V_DATA   0x30
#define XCOLOR_CONVERT_AXILITES_BITS_C2_C2_V_DATA   10
#define XCOLOR_CONVERT_AXILITES_ADDR_C2_C3_V_DATA   0x38
#define XCOLOR_CONVERT_AXILITES_BITS_C2_C3_V_DATA   10
#define XCOLOR_CONVERT_AXILITES_ADDR_C3_C1_V_DATA   0x40
#define XCOLOR_CONVERT_AXILITES_BITS_C3_C1_V_DATA   10
#define XCOLOR_CONVERT_AXILITES_ADDR_C3_C2_V_DATA   0x48
#define XCOLOR_CONVERT_AXILITES_BITS_C3_C2_V_DATA   10
#define XCOLOR_CONVERT_AXILITES_ADDR_C3_C3_V_DATA   0x50
#define XCOLOR_CONVERT_AXILITES_BITS_C3_C3_V_DATA   10
#define XCOLOR_CONVERT_AXILITES_ADDR_BIAS_C1_V_DATA 0x58
#define XCOLOR_CONVERT_AXILITES_BITS_BIAS_C1_V_DATA 10
#define XCOLOR_CONVERT_AXILITES_ADDR_BIAS_C2_V_DATA 0x60
#define XCOLOR_CONVERT_AXILITES_BITS_BIAS_C2_V_DATA 10
#define XCOLOR_CONVERT_AXILITES_ADDR_BIAS_C3_V_DATA 0x68
#define XCOLOR_CONVERT_AXILITES_BITS_BIAS_C3_V_DATA 10

